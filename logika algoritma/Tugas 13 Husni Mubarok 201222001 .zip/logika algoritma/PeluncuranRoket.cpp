#include <conio.h>
#include <stdio.h>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
	int i = 10;
		
	do{
	    cout<<  i <<" ";
	    i--;
	} while( i > 0);
	cout<< "Go! ";
}