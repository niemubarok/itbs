#include <iostream>
#include <conio.h>

int main(int argc, char *argv[])
{
 int i =0;
 do{   
printf ("swadharma \n");
i++;
}
while(i <10);
}